<?php
session_start();
$sitePath = "http://127.0.0.1/qr/s.php";
$conn = mysqli_connect("localhost","root","","qr");


?>