<?php
// $pass = "admin";
// echo password_hash($pass,PASSWORD_DEFAULT);

?>