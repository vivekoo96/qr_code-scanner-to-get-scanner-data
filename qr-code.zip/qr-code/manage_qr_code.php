
                <?php 
                include "header.php";
                check_auth();
                $msg="";
                $name = "";
                  $link = "";
                  $color = "";
                  $size = "";
                  $id = 0;
                  $condition = "";
                  if( $_SESSION['QR_USER_ROLE'] == 1){
                    $condition = " and added_by='". $_SESSION['QR_USER_ID']."'";
                  }
                  if(isset($_GET['id']) && $_GET['id'] >0){
                    $id = get_safe_value($_GET['id']);
                    $res = mysqli_query($conn,"SELECT * FROM `qr-_code` WHERE id='$id' $condition");
                    if(mysqli_num_rows($res) > 0 ){
                    $row = mysqli_fetch_assoc($res);
                    $name = $row['name'];
                    $link = $row['link'];
                    $color = $row['color'];
                    $size = $row['size'];
                    }else{
                      redirect('qr-codes.php');
                    }
                  }
                if(isset($_POST['submit'])){
                  $id = get_safe_value($_GET['id']);
                  $name = get_safe_value($_POST['name']);
                  $link = get_safe_value($_POST['link']);
                  $color = get_safe_value($_POST['color']);
                  $size	 = get_safe_value($_POST['size']);
                  $added_by =   $_SESSION['QR_USER_ID'];
                  $status = 1;
                  $added_on = date('Y-m-d h:i:s');
                  if($id>0){
                      $query = "UPDATE `qr-_code`  set name='$name',link='$link',color='$color',size='$size' where id='$id' $condition";
                      mysqli_query($conn,$query);
                    }else{
                      $query = "INSERT INTO `qr-_code`(`name`,`link`,`color`,`size`,`added_by`,`status`,`added_on`)VALUES('$name','$link','$color','$size','$added_by','$status','$added_on')";
                      mysqli_query($conn,$query);
                    }
                   
                    redirect('qr-codes.php');
                  }
                

              
                
                ?>
             <div id="layoutSidenav_content">
                <main>
                <div class="row">
                <div class="title py-2 bg-light my-3 col-md">
                    <h3 class="ml-5 text-primary">Add QR Code</h3>
                </div>
                </div>
                <div class="card-body">
                <div class="row justify-content-md-center">
                    <div class="col-md-11 bg-light">
                    <form method="post">
  <div class="form-group">

  <div class="form-group">
    <label for="name" class="h5">Name</label>
    <input type="text" class="form-control" id="name" placeholder="Name" name="name" required value="<?php echo $name ;?>">
  </div>
  <div class="form-group">
    <label for="Link" class="h5">Link</label>
    <input type="text" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Link" name="link" required value="<?php echo $link;?>">
  
  </div>
  <div class="form-group">
    <label for="color" class="h5">Color</label>
    <select name="color"  class="form-control">
    <option value="">
    Select Color
    </option>
    <?php
    $sizeSQL = mysqli_query($conn,"SELECT * FROM `color` where status = 1");
    while($res = mysqli_fetch_assoc($sizeSQL)){
      $is_selected = "";
      if($res['color'] == $color){
        $is_selected = "selected";
      }
      echo '<option value="'.$res['color'].'"'.$is_selected.'>'
        .$res['color'].
      '</option>';
    } 
    ?>
  </select>
  
  </div>
  <div class="form-group">
    <label for="size" class="h5">Size</label>
    <select name="size"  class="form-control">
    <option value="">
    Select Size
    </option>
    <?php
    $sizeSQL = mysqli_query($conn,"SELECT * FROM `size` where status = 1 order by size asc ");
    while($res = mysqli_fetch_assoc($sizeSQL)){
      $is_selected = "";
      if($res['size'] == $size){
        $is_selected = "selected";
      }
      echo '<option value="'.$res['size'].'"'.$is_selected.'>'
        .$res['size'].
      '</option>';
    } 
    ?>
  </select>
  </div>
 
 
  
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>
                    </div>

                </div>
          
                </div>       
                </main>
                <?php
                 include "footer.php";
                ?>
            