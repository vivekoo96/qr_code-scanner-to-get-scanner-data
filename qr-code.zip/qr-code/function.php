<?php
function prx($arr){
    echo "<pre>";
    return print_r($arr);  
}
  function get_safe_value($str){
      global $conn;
      if($str != ''){
          return mysqli_real_escape_string($conn,$str);
      }
  }

  function redirect($page){
      ?>
      <script>
          window.location.href = '<?php echo $page;?>';
      </script>
      <?php
  }

  function check_auth(){
      if(!isset($_SESSION['QR_USER_LOGIN'])){
          redirect('index.php');
      }
  }

  
  function check_admin_auth(){
    if($_SESSION['QR_USER_ROLE'] != 0){
        redirect('profile.php');
    }
}
?>