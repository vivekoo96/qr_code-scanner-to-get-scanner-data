
                <?php 
                include "header.php";
                check_auth();
                check_admin_auth();
                $msg="";
                $name = "";
                  $email = "";
                  $total_qr = "";
                  $total_hit = "";
                  $id = 0;
                  $password_required = "required";
                if(isset($_POST['submit'])){
                  $id = get_safe_value($_GET['id']);
                  $name = get_safe_value($_POST['name']);
                  $email = get_safe_value($_POST['email']);
                  $password = password_hash(get_safe_value($_POST['password']),PASSWORD_DEFAULT);
                  $total_qr = get_safe_value($_POST['total_qr']);
                  $total_hit = get_safe_value($_POST['total_hit']);
                  $role = 1;
                  $status = 1;
                  $added_on = date('Y-m-d h:i:s');
                  $email_sql = "";
                  if($id > 0){
                    $email_sql = " and id!='$id'";
                  }
                  if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `users` WHERE email='$email' $email_sql"))>0){
                      $msg = "Email id already register.";
                  }else{
                    if($id > 0){
                      $password_str = "";
                      if($password != ''){
                        $password_str = ",password='$password'";
                      }
                      $query = "UPDATE users set name='$name',email='$email',total_qr='$total_qr',total_hit='$total_hit' $password_str where id='$id'";
                      mysqli_query($conn,$query);
                    }else{
                      $query = "INSERT INTO users(`name`,`email`,`password`,`total_qr`,`total_hit`,`role`,`status`,`added_on`)VALUES('$name','$email','$password','$total_qr','$total_hit','$role','$status','$added_on')";
                      mysqli_query($conn,$query);
                    }
                   
                    redirect('users.php');
                  }
                }

                if(isset($_GET['id']) && $_GET['id'] >0){
                  $id = get_safe_value($_GET['id']);
                  $res = mysqli_query($conn,"SELECT * FROM `users` WHERE id='$id'");
                  if(mysqli_num_rows($res) > 0 ){
                  $row = mysqli_fetch_assoc($res);
                  $name = $row['name'];
                  $email = $row['email'];
                  $total_qr = $row['total_qr'];
                  $total_hit = $row['total_hit'];
                  $password_required = "";
                  }else{
                    redirect('users.php');
                  }
                }
                
                ?>
            <div id="layoutSidenav_content">
                <main>
                <div class="row">
                <div class="title py-2 bg-light my-3 col-md">
                    <h3 class="ml-5 text-primary">Manage User</h3>
                </div>
                </div>
                <div class="card-body">
                <div class="row justify-content-md-center">
                    <div class="col-md-11 bg-light">
                    <form method="post">
  <div class="form-group">

  <div class="form-group">
    <label for="name" class="h5">Name</label>
    <input type="text" class="form-control" id="name" placeholder="Name" name="name" required value="<?php echo $name ;?>">
  </div>
  <div class="form-group">
    <label for="email" class="h5">Email address</label>
    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email" required placeholder="Enter email" value="<?php echo $email ;?>">
  
  </div>
  <div class="form-group">
    <label for="password" class="h5">Password</label>
    <input type="password" class="form-control" id="email" aria-describedby="emailHelp" name="password" <?php echo  $password_required; ?> placeholder="Password">
  
  </div>
  <div class="form-group">
    <label for="Total QR Code" class="h5">Total QR Code</label>
    <input type="text" class="form-control" id="text" aria-describedby="emailHelp" name="total_qr" placeholder="Total QR Code" value="<?php echo $total_qr ;?>">
  
  </div>
  <div class="form-group">
    <label for="Total QR Hits" class="h5">Total QR Hits</label>
    <input type="text" class="form-control" id="email" aria-describedby="emailHelp" name="total_hit" placeholder="Total QR Hits" value="<?php echo $total_hit;?>">
  
  </div>
  <?php
  if($msg != ""){
  ?>
  <p class="alert alert-danger my-3"><?php echo $msg;?></p>
  <?php
  }
  ?>
 
  
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>
                    </div>

                </div>
          
                </div>       
                </main>
                <?php
                 include "footer.php";
                ?>
            