
                <?php 
                include "header.php";
                check_auth();
                
                ?>
            <div id="layoutSidenav_content">
                <main>
                <div class="row">
                <div class="title py-2 bg-light my-3 col-md">
                    <h3 class="ml-5 text-primary">Profile</h3>
                   
                </div>
                </div>
                <div class="card-body">
                            
                </main>
                <?php
                 include "footer.php";
                ?>
            