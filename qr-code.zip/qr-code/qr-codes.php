<?php 
                include "header.php";
                check_auth();
                $condition = "";
                if( $_SESSION['QR_USER_ROLE'] == 1){
                  $condition = " and added_by='". $_SESSION['QR_USER_ID']."'";
                }
                if(isset($_GET['status']) && $_GET['status']!="" && isset($_GET['id']) && $_GET['id']>0){
                    $status = get_safe_value($_GET['status']);
                    $id = get_safe_value($_GET['id']);
                    if($status == "active"){
                        $status = 1;
                    }else{
                        $status = 0;
                    }
                    mysqli_query($conn,"UPDATE `qr-_code` set status = '$status' where id='$id' $condition");
                    redirect("qr-codes.php");
                }
               

                $query = "SELECT  * FROM `qr-_code` where 1 $condition order by added_on desc";
                $res = mysqli_query($conn,$query);
                
                ?>
            <div id="layoutSidenav_content">
                <main>
                <div class="row">
                <div class="title py-2 bg-light my-3 col-md">
                    <h3 class="ml-5 text-primary">QR Code</h3>
                    <h5 class="ml-5 text-success"> <a href="manage_qr_code.php">Add QR</a> </h5>
                </div>
                </div>
                <div class="card-body">
                        <?php if(@mysqli_num_rows($res)>0){?>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                            <th>#</th>
                                                <th>Name</th>
                                                <th>QR Code</th>
                                                <th>Link</th>
                                                <th>Color</th>
                                                <th>Size</th>
                                                <th>Added On</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            while($row = mysqli_fetch_assoc($res)){
                                            ?>
                                                <tr>
                                           
                                                <td><?php echo $i++?></td>
                                                <td><?php echo $row['name']?>
                                                <p><a href="qr_report.php?id=<?php echo $row['id'];?>">Report</a></p>
                                                </td>
                                                <td>
                                                <a target="_blank" href="https://chart.apis.google.com/chart?cht=qr&chs=<?php echo $row['size']?>&chco=<?php echo $row['color']?>&chl=<?php echo $sitePath;?>?id=<?php echo $row['id'];?>">
                                                <img src="https://chart.apis.google.com/chart?cht=qr&chs=<?php echo $row['size']?>&chl=<?php echo $row['link']?>&chco=<?php echo $row['color']?>" width="100px"/></a>
                                                </td>
                                                <td><?php echo $row['link']?></td>
                                                <td><?php echo $row['color']?>
                                                <span style="background-color:#<?php echo $row['color'];?>;">&nbsp;&nbsp;&nbsp;</span>
                                                </td>
                                                <td><?php echo $row['size']?></td>
                                                <td><?php echo $row['added_on']?></td>
                                                <td>
                                                    <a href="manage_qr_code.php?id=<?php echo $row['id'];?>">Edit</a>
                                                    &nbsp;
                                                    <?php
                                                    $status = "active";
                                                    $strStatus = "Deactive";
                                                    if($row['status'] == 1){
                                                        $status = "deactive";
                                                        $strStatus = "Active";
                                                    }
                                                    ?>
                                                    <a href="?id=<?php echo $row['id'];?>&status=<?php echo $status ?>"><?php echo $strStatus?></a>
                                                    &nbsp;
                                                </td>
                                            </tr>
                                                <?php
                                            }
                                            ?>
                                          
                                        </tbody>
                                    </table>
                                </div>
                                <?php
                        }else{
                            echo "No data found";
                        }
                                ?>
                </div>       
                </main>
                <?php
                 include "footer.php";
                ?>
            