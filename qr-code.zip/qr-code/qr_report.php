
                <?php 
                include "header.php";
                check_auth();
                $device = "";
                $date = "";
                $count = "";

                if(isset($_GET['id']) && $_GET['id']> 0 ){
                    $condition = "";
                    if($_SESSION['QR_USER_ROLE'] == 1){
                        $condition = " and qr-_code.added_by='".$_SESSION['QR_USER_ID']."'";
                    }
                    $id = get_safe_value($_GET['id']);
                     $res = mysqli_query($conn,"select qr_traffic.*,qr-_code.name from qr_traffic,qr-_code where qr-_code.id='$id'");
                    if(mysqli_num_rows($res) > 0 ){
                    $row = mysqli_fetch_assoc($res);
                    $name = $row['device'];

                    }else{
                        redirect('qr-codes.php');
                    }

                }


                ?>
                 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                <script type="text/javascript">
                    google.charts.load('current', {'packages':['corechart']});
                    google.charts.setOnLoadCallback(drawDeviceChart);
                    google.charts.setOnLoadCallback(drawOSChart);
                    google.charts.setOnLoadCallback(drawBrowserChart);



                                function drawDeviceChart() {

                            var data = google.visualization.arrayToDataTable([
                            ['Device', 'Total Users'],
                            ['Mobile',     11],
                            ['Tabtel',      2],
                            ['PC',           2]

                            ]);

                            var options = {
                            title: 'Device'
                            };

                            var chart = new google.visualization.PieChart(document.getElementById('device'));

                            chart.draw(data, options);
                            }



                            function drawOSChart() {

                            var data = google.visualization.arrayToDataTable([
                            ['OS', 'Total Users'],
                            ['iOS',     11],
                            ['Android',      2],
                            ['Window',           2]

                            ]);

                            var options = {
                            title: 'OS'
                            };

                            var chart = new google.visualization.PieChart(document.getElementById('os'));

                            chart.draw(data, options);
                            }


                            function drawBrowserChart() {

                            var data = google.visualization.arrayToDataTable([
                            ['Browser', 'Total Users'],
                            ['Chrome',     11],
                            ['Edge',      2],
                            ['Firefox',           2]

                            ]);

                            var options = {
                            title: 'Browser'
                            };

                            var chart = new google.visualization.PieChart(document.getElementById('browser'));

                            chart.draw(data, options);
                            }
                                </script>
            <div id="layoutSidenav_content">
                <main>
                <div class="row">
                <div class="title py-2 bg-light my-3 col-md">
                    <h3 class="ml-5 text-primary">QR Report</h3>
                </div>
                </div>
               
            <div class="row">
               <div class="col-4">
                    <div class="card">
                       <div class=" bg-light card-body" id="device"></div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card">
                       <div class=" bg-light card-body" id="os"></div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card">
                       <div class=" bg-light card-body" id="browser"></div>
                    </div>
                </div>
                  
            </div>

            <div class="card-body">
                       
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                            <th>#</th>
                                                <th>Device</th>
                                                <th>Date</th>
                                                <th>Count</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>

                                            </tr>
                                          
                                          
                                        </tbody>
                                    </table>
                                </div>
                
                </main>
                <?php
                 include "footer.php";
                ?>
            